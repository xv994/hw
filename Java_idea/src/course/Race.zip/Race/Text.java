package course.Race;

public class Text {
    
    public static void main(String[] args) {

        Menu menu = new Menu();
        menu.getMenu();
        
    }
}
